import com.amazonaws.services.lambda.runtime.Context;
import java.util.*;

public class LambdaMethodHandler {
    public String handleRequest(Map<String,Object> input, Context context) {
        context.getLogger().log("Input: " + input);
        return "HELLO FRONT END FROM THE BACKEND - YOUR INPUT WAS" + input;
    }
}