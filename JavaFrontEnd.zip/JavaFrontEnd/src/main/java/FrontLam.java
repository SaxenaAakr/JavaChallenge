import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestStreamHandler;
import org.apache.commons.io.IOUtils;
import com.amazonaws.services.lambda.AWSLambdaAsyncClient;

import com.amazonaws.services.lambda.runtime.Context;


public class FrontLam implements RequestStreamHandler {
    public void handleRequest(InputStream inputStream,
                              OutputStream outputStream, Context context) throws IOException {

        try {

            String backFunctName = "arn:aws:lambda:eu-central-1:590189865299:function:JavaChallenge";
//            here we have just got the ARN of the backend function
            String payload = "{ \"frontEndRequest\" : \"Hello Backend from the front end\"}";
//            here we are processing the parameter for the backend function to JSON object -which it likes

            AWSLambdaAsyncClient client = new AWSLambdaAsyncClient();
            client.withRegion(Regions.EU_CENTRAL_1); // check right region
            InvokeRequest request = new InvokeRequest();
            request.withFunctionName(backFunctName).withPayload(payload);
            InvokeResult invoke = client.invoke(request);

//            outputStream.write(("Hello World from Front End").getBytes());
//            outputStream.write(backFunctName.getBytes());
            String newContent = new String(invoke.getPayload().array(), StandardCharsets.UTF_8);
            outputStream.write(newContent.getBytes());
            context.getLogger().log("Response : " + newContent);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
